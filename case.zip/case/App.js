
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import React, { useState,useEffect } from 'react';


import AssetExample from './components/AssetExample';


import { Card } from 'react-native-paper';

export default function App() {


  useEffect(() => {
    kurtSayisi(); 
 
  }, []);

  
const [kurtTuru, setKurtTuru] = useState([]); 
const [tekrar, setTekrar] = useState([0,0,0,0,0]); 
const [sonuc, setsonuc] = useState(); 

  function kurtSayisi(){
 
  
 
    var sayi =  Math.floor(Math.random() * 7); 
    
        

   for (let i = 0; i < 8; i++) {
 
      var rand =  Math.floor(Math.random() * 5+1);  
        kurtTuru.push(rand)

      } 
     
       setKurtTuru( arr => [...arr]);

    tekrarlanan(); 
  
  }

 function tekrarlanan(){

   for (var i=0; i  < kurtTuru.length ; i++){
    switch(kurtTuru[i]) {
    case 1:
     tekrar[0]+=1;
 
    break;
    case 2:
    tekrar[1]+=1;
    break;
  case 3:
  tekrar[2]+=1;
    break;
    case 4:
    tekrar[3]+=1;
    break;
  case 5:
  tekrar[4]+=1;
    break;
  default:
 
}

   }
 
  setTekrar( arr => [...arr]);

  kalabalikTur();
}

function kalabalikTur(){
 const max = Math.max.apply(null, tekrar);
setsonuc(tekrar.indexOf(max))


}
  
  return ( 
    <View style={styles.container}>
    <Text style={styles.paragraph}>
   
       En kalabalık tür  {sonuc+1}. kurt türüdür. 
 

      </Text>
      <Text style={styles.paragraph}>

      

   
        Kurt Türleri:
      { kurtTuru.map((item, key)=>(
         <Text key={key} style={styles.TextStyle}> { item } </Text>)
         )}

      </Text> 

      <Text style={styles.paragraph}>
   
        Tekrar sayıları:


      </Text>

      <Text style={styles.paragraph}>
        1 türünde: {tekrar[0]}
       </Text>
    
    <Text style={styles.paragraph}>
        2 türünde: {tekrar[1]}
       </Text>

       <Text style={styles.paragraph}>
        3 türünde: {tekrar[2]}
       </Text>

       <Text style={styles.paragraph}>
       4 türünde: {tekrar[3]}
       </Text>

       <Text style={styles.paragraph}>
       5 türünde: {tekrar[4]}
       </Text>
    </View> 
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
